#!/bin/sh
# Add your startup script
cp /flag /home/ctf/flag
# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;
